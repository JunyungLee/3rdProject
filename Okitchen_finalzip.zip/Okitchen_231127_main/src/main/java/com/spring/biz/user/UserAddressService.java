package com.spring.biz.user;

public interface UserAddressService {
	void updateAddress(UsersVO user);
}
