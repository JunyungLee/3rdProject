package com.spring.biz.view.recipe;

public class RecipeAjaxController {

}
